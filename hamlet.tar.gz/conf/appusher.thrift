namespace py sqc

service Appusher {
    string ping(),
    oneway void pushmsg(1:required string sender, 2:required list<i32> apptypes, 3:required list<i32> platforms,
                        4:required i32 mode, 5:required list<i32> to, 6:required string content, 7:string extra)
}
