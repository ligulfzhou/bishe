# -*- coding: utf-8 -*-
import os
from multiprocessing import cpu_count
from util.logger import initlog

ROOT_PATH = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEPLOY_PATH = os.path.dirname(ROOT_PATH)
PROCESS_SN = os.path.basename(ROOT_PATH)
log = initlog({
    'INFO': '%s/log/hamlet-%s.info.log' % (DEPLOY_PATH, PROCESS_SN),
    'NOTE': '%s/log/hamlet-%s.note.log' % (DEPLOY_PATH, PROCESS_SN),
    'ERROR': '%s/log/hamlet-%s.error.log' % (DEPLOY_PATH, PROCESS_SN)
}, mode='timed', backup_count=15)

CPU_COUNT = cpu_count()
CACHE_SERVER = {'host': '127.0.0.1', 'port': 9736, 'db': 1, 'password': 'h4M1eT#S0z'}
SESSION_SERVER = {'host': '127.0.0.1', 'port': 9736, 'db': 0, 'password': 'h4M1eT#S0z'}
MONGO_HAMLET = {'master': 'mongodb://sqc_user:zY#s9C)1z0@127.0.0.1:28017/hamlet', 'slave': 'mongodb://sqc_read:)Z!0c(S3yZ@127.0.0.1:28017/hamlet', 'replset': 'sqc'}
MONGO_STORE = {'master': 'mongodb://sqc_user:zY#s9C)1z0@127.0.0.1:28017/store', 'slave': 'mongodb://sqc_read:)Z!0c(S3yZ@127.0.0.1:28017/store', 'replset': 'sqc'}
MONGO_UTIL = {'master': 'mongodb://sqc_user:zY#s9C)1z0@127.0.0.1:28017/util', 'slave': 'mongodb://sqc_read:)Z!0c(S3yZ@127.0.0.1:28017/util', 'replset': 'sqc'}

BASE_NUMERALS = 'HAMLET502CZY81SQBU3FVOI4KWNJ6PXGR79D'
SESSION_SECRET = 'ReOdPZCuRGaY8XFQM0NnhWEAAJBaoETts8NoXBU6wTk='
SESSION_TIMEOUT = 2592000

QTPAY_CONF = {
    'url': 'https://qtapi.qfpay.com',
    'apikey': 'B65E3778985BD7E9B53F78A71598BE43',
    'appcode': '32762C1D4D9F738F2C2D1922F94E0EBD',
    'serverkey': '2738057FC3A44B2684926542426A1747'
}

PUSH_SERVER = {
    'hosts': [{'addr': ('127.0.0.1', 5100), 'timeout': 2000}, {'addr': ('127.0.0.1', 5101), 'timeout': 2000}],
    'thrift': os.path.join(ROOT_PATH, 'conf', 'appusher.thrift'),
}
SMS_SERVER = {
    'hosts': [{'addr': ('127.0.0.1', 5200), 'timeout': 2000}, {'addr': ('127.0.0.1', 5201), 'timeout': 2000}],
    'thrift': os.path.join(ROOT_PATH, 'conf', 'smserver.thrift'),
}

WX_CONF = {
    'appid': 'wx7da6f4663012671b',
    'secret': '65595d1951ccb0bc8b8ed8326b1cdbeb',
    'token': 'a87d23884f6b46039b392e6a92168660'
}

IMAGE_DOMAIN = 'https://img.shequcun.com'
UPLOAD_PATH = '/home/hamlet/shequcun/upload'
IMG_CACHE_URL = 'http://7xjgn9.com2.z0.glb.qiniucdn.com'
