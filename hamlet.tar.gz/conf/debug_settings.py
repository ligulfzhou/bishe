# -*- coding: utf-8 -*-
import os
from multiprocessing import cpu_count
from util.logger import initlog

ROOT_PATH = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
log = initlog({
    'INFO': '%s/log/hamlet.info.log' % ROOT_PATH,
    'NOTE': '%s/log/hamlet.note.log' % ROOT_PATH,
    'WARN': '%s/log/hamlet.warn.log' % ROOT_PATH,
    'ERROR': '%s/log/hamlet.error.log' % ROOT_PATH
}, True, mode='timed', backup_count=15)

CPU_COUNT = cpu_count()
CACHE_SERVER = {'host': '192.168.1.100', 'port': 6379, 'db': 1, 'password': 'redis%sqc'}
SESSION_SERVER = {'host': '192.168.1.100', 'port': 6379, 'db': 0, 'password': 'redis%sqc'}
MONGO_HAMLET = {'master': '192.168.1.100:27017'}
MONGO_STORE = {'master': '192.168.1.100:27017'}
MONGO_UTIL = {'master': '192.168.1.100:27017'}

BASE_NUMERALS = 'HAMLET502CZY81SQBU3FVOI4KWNJ6PXGR79D'
SESSION_SECRET = 'ReOdPZCuRGaY8XFQM0NnhWEAAJBaoETts8NoXBU6wTk='
SESSION_TIMEOUT = 86400

QTPAY_CONF = {
    'url': 'https://qtsandbox.qfpay.com',
    'apikey': '579333EF2A15930027862E739A0569E7',
    'appcode': '795391E322A6E83BDDD4148EE5FBEE48',
    'serverkey': 'A817AB1DA287F60CA8C5680456E12822'
}

PUSH_SERVER = {
    'hosts': [{'addr': ('192.168.1.100', 5100), 'timeout': 2000}, {'addr': ('192.168.1.100', 5101), 'timeout': 2000}],
    'thrift': os.path.join(ROOT_PATH, 'conf', 'smserver.thrift'),
}
SMS_SERVER = {
    'hosts': [{'addr': ('192.168.1.100', 5200), 'timeout': 2000}, {'addr': ('192.168.1.100', 5201), 'timeout': 2000}],
    'thrift': os.path.join(ROOT_PATH, 'conf', 'smserver.thrift'),
}

WX_CONF = {
    'appid': 'wx7da6f4663012671b',
    'secret': '65595d1951ccb0bc8b8ed8326b1cdbeb',
    'token': 'a87d23884f6b46039b392e6a92168660'
}

IMAGE_DOMAIN = 'http://127.0.0.1:8000/static/upload'
UPLOAD_PATH = os.path.join(ROOT_PATH, 'static', 'upload')
IMG_CACHE_URL = None
